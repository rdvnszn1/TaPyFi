


def main():
    """Indıcator Lib For Trader"""
    pass
    # Read URL of the Real Python feed from config file

if __name__ == "__main__":
    main()

